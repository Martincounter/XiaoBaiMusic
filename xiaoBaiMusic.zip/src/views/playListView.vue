<template>
  <div class="container-com">
    <div class="body">播放列表</div>
  </div>
</template>
<script lang="ts" setup>
const getData = () => {
  console.log("获取数据");
};
</script>
<style scoped lang="less">
.container-com {
  .body {
    // padding: var(--padding-contain);
  }
}
</style>
